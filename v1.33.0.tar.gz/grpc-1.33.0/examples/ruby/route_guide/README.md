# gRPC Basics: Ruby sample code

The files in this folder are the samples used in [gRPC Basics: Ruby][],
a detailed tutorial for using gRPC in Ruby.

[gRPC Basics: Ruby]:https://grpc.io/docs/languages/ruby/basics
